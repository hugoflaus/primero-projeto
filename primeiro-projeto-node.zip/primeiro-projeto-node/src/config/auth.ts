export default {
  jwt: {
    secret: '63d398d3c03a91788b93f25fb410c5af',
    expiresIn: '1d',
  },
};
